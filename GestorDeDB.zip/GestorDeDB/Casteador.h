#pragma once
#include <vector>
#include <string>

using namespace std;
class Casteador
{
	vector<string> s = { "int","string","int" };
	void convert() {
		
		for (int i = 0; i < s.size(); i++) {
			if (s[i] == "int") {
				
			}
		}
		

	}
};

