#include "StringAdapter.h"
